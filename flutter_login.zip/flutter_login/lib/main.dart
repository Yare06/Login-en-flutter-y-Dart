import 'package:flutter/material.dart';

void main() => runApp(const MyApp());

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Material App',
      home: Inicio(),
    );
  }
}

class Inicio extends StatelessWidget {
  const Inicio({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Login con Flutter'),
      ),
      body: Cuerpo(),
    );
  }
}

class Cuerpo extends StatelessWidget {
  const Cuerpo({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        image: DecorationImage(
          image: NetworkImage('https://cdn.create.vista.com/api/media/small/461937678/stock-photo-seamless-pattern-hearts-digital-illustration-decor-valentine-day-wallpaper-children'),
          fit: BoxFit.cover)),
      child: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Etiqueta(),
          CampoUser(),
          CampoPass(),
          BotonEntrar()
          ],
      ),
    );
  }
}
Widget Etiqueta(){
  return Container(child: Center(child: Text('Sing in', style: TextStyle(fontSize: 25.0,color: Colors.black)),),);
}
Widget CampoUser(){
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 15.0),
    child: 
  TextField(
    decoration: InputDecoration(
      hintText: 'User',
      fillColor: Colors.white,
      filled: true)));
}
Widget CampoPass(){
  return Container(
    padding: EdgeInsets.symmetric(horizontal: 15.0, vertical: 10.0),
    child: 
  TextField(
    obscureText: true,
    decoration: InputDecoration(
      hintText: 'Password',
      fillColor: Colors.white,
      filled: true)
      ),
      );
}
Widget BotonEntrar(){
  return ElevatedButton(onPressed: (){},
  child: Text(' Intro now ',
  style: TextStyle(
    fontSize: 20.0,
    color: const Color.fromARGB(255, 49, 114, 167)
    ),
    ),
  );
}

